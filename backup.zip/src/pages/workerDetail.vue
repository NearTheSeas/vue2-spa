<template>
  <div id="worker_detail">
    <div class="header">
      <div class="avator">
        <img src="../assets/images/worker.png" alt="">
      </div>
    </div>
    <div class="worker_info request">
      <div class="wrapper">
        <span>姓名：</span>
      </div>
      <div class="wrapper">
        <span>期望薪资：</span>
      </div>
      <div class="wrapper">
        <span>最近职位：</span>
      </div>
      <div class="wrapper">
        <span>联系电话：</span>
      </div>
      <div class="wrapper">
        <span>地址：</span>
      </div>
    </div>
    <div class="p20"></div>
    <div class="request">
      <div class="wrapper">
        <span>我能做什么？</span>
        <i class="icon icon-arrow-right"></i>
        <ul>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>
      <div class="wrapper">
        <span>我会做什么</span>
        <i class="icon icon-arrow-right"></i>
        <ul>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>
      <div class="wrapper">
        <span>个人简介</span>
        <i class="icon icon-arrow-right"></i>
        <ul>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>
    </div>
    <div class="toolBar">
      <div class="p30"></div>
      <div class="btns">
        <a href="javascript:;" class="tel">
          <i></i>
        </a>
        <a href="javascript:;" class="msg">
          <i></i>
        </a>
        <a href="javascript:;" class="btn"><span>申请职位</span></a>
      </div>
    </div>
  </div>
</template>
<script>
    export default {
        name: 'jobDetail',
        data() {
            
            return {
                jobs: {}
            }
        },
        methods: {
            // 点击申请按钮触发的事件
            apply(jobId) {
               
            }
        }
    }
</script>
<style>
  #worker_detail .header {
    border-bottom: 1px solid #eee;
    position: relative;
    height:7.75rem;
  }
  
  #worker_detail .header .avator {
    border-radius: 50%;
    overflow: hidden;
    width: 5.625rem;
    height: 5.625rem;
    border:1px solid #ddd;
    text-align: center;
    position: absolute;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%);
  }

  #worker_detail .header .avator img{
      height: 100%;
  }
  
  #worker_detail .request {
      padding-left:0.625rem;
  }

  #worker_detail .request .wrapper {
    background: #fff;
    font-size: 0.9375rem;
    padding: 0.825rem 0 0.825rem 0.625rem;
  }
  
  #worker_detail .request .wrapper {
    border-bottom: 1px solid #eee;
  }

  #worker_detail .worker_info .wrapper:nth-last-child(1){
      border-bottom: none;
  }
  
  #worker_detail .request .wrapper .icon.icon-arrow-right {
    float: right;
    margin-right: 0.625rem;
    margin-top: .25rem;
  }
  
  #worker_detail .toolBar {
    width: 100%;
    position: fixed;
    bottom: 0;
    height: 4.375rem;
  }
  
  #worker_detail .toolBar .btns {
    padding: 0.3125rem 0.875rem;
  }
  
  #worker_detail .toolBar .btns a {
    float: left;
    height: 2.8125rem;
    min-width: 2.8125rem;
    border-radius: 5px;
  }
  
  #worker_detail .toolBar .btns .tel {
    background: #3ebefb;
    margin-right: 0.625rem;
  }
  
  #worker_detail .toolBar .btns .tel i {
    display: block;
    width: 100%;
    height: 100%;
    background: url(../assets/images/phone.png) no-repeat center center / 1.875rem 1.875rem;
  }
  
  #worker_detail .toolBar .btns .msg {
    background: #3ebefb;
  }
  
  #worker_detail .toolBar .btns .msg i {
    display: block;
    width: 100%;
    height: 100%;
    background: url(../assets/images/message.png) no-repeat center center / 1.875rem 1.875rem;
  }
  
  #worker_detail .toolBar .btns .btn {
    background: #ff5959;
    font-size: 1.5rem;
    padding: 0.625rem;
    float: right;
    color: #fff;
    width: 13.625rem;
    text-align: center;
  }

</style>
