<template>
  <div>
    <h1>Not Found!</h1>
  </div>
</template>

<script>
  export default {
    name: 'not-found'
  }
</script>

<style scoped>
  h1 {
    height: 100%;
    line-height: 100%;
    text-align: center;
  }
</style>
