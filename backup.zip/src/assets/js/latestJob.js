var app = new Vue({
    el: '#app',
    data: {
        searchText: "",
        jobs: [
            { "id": "1", "jobName": "铆焊师傅", "location": "西安", "jobType": "技工", "salary": "200", "pv": "10" },
            { "id": "2", "jobName": "汽修钣金油漆工", "location": "北京", "jobType": "油漆工", "salary": "200", "pv": "10" },
            { "id": "3", "jobName": "铆焊师傅", "location": "西安", "jobType": "技工", "salary": "200", "pv": "10" }
        ]
    },
    methods: {
        apply() {
            this.$toast('It Works!')
        }
    }
})